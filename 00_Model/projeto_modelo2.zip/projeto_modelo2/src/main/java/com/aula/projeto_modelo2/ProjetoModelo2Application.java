package com.aula.projeto_modelo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoModelo2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoModelo2Application.class, args);
	}

}
