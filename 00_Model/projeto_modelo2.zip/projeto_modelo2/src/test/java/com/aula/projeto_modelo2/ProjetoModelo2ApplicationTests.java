package com.aula.projeto_modelo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoModelo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
