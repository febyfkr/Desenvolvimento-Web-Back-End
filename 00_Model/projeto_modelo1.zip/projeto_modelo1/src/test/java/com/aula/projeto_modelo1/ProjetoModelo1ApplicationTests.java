package com.aula.projeto_modelo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoModelo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
