package com.aula.projeto_modelo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoModelo1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoModelo1Application.class, args);
	}

}
