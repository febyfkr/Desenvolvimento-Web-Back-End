package com.aula.projeto_modelo3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoModelo3Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoModelo3Application.class, args);
	}

}
