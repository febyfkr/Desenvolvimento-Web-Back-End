package com.aula.projeto_modelo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoModelo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
